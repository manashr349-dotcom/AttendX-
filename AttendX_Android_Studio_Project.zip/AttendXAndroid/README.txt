AttendX Android Studio project
Package: com.osme.attendx
App name: AttendX
Minimum Android: 6.0 (API 23)

BUILD APK:
1. Install Android Studio on a computer.
2. Open this AttendXAndroid folder (File > Open).
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK output: app/build/outputs/apk/debug/app-debug.apk

The app runs the bundled offline HTML tracker inside Android WebView.
Attendance data is stored locally on the device via WebView localStorage.
No account or internet permission is requested.
